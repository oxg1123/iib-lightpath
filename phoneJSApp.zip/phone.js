var app = require('express');

var accountPhoneRecords = '{"account":[{"phone": "5555555555", "circuitid": " "},{"phone": "4444444444", "circuitid": " "},{"phone": "3333333333", "circuitid": " "}]}';

// server.js

// BASE SETUP
// =============================================================================

// call the packages we need
var express    = require('express');        // call express
var app        = express();                 // define our app using express
var bodyParser = require('body-parser');

// configure app to use bodyParser()
// this will let us get the data from a POST
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

var port = process.env.PORT || 1337;        // set our port

// ROUTES FOR OUR API
// =============================================================================
var router = express.Router();              // get an instance of the express Router

// test route to make sure everything is working (accessed at GET http://localhost:1337/)
router.get('/phone', function(req, res) {
    res.json({  "account": [    {      "phone": "5555555555",      "circuitid":  null   },    {      "phone": "4444444444",      "circuitid": null    },    {      "phone": "3333333333",      "circuitid": null    }  ]});   
});

router.get('/circuit', function(req, res) {
    res.json({  "account": [    {      "phone": null,      "circuitid": "12345"    },    {      "phone": null,      "circuitid": "333321"    },    {      "phone": null,      "circuitid": "444312"    }  ]}); 
});


router.get('/', function(req, res) {
    res.json("Try /phone or /circuit"); 
});



// more routes for our API will happen here

// REGISTER OUR ROUTES -------------------------------
// all of our routes will be prefixed with /phone
app.use('/', router);


// START THE SERVER
// =============================================================================
app.listen(port);
console.log('Magic happens on port ' + port);
